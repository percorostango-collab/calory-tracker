# <Nome progetto>

## Obiettivo
<una frase>

## Stack e versioni (verificate)
- Node <x> / npm <y>
- <framework>@<versione>, <ORM>@<versione>, <DB>
- Piattaforma: Windows. Niente moduli nativi da compilare.

## Comandi
- Sviluppo: `npm run dev` (porta 3000)
- Verifica: `npx tsc --noEmit` ; `npm run build` (solo con dev server spento) ; `npm test`

## Criteri di "fatto"
1. tsc senza errori, build ok.
2. GET / = 200 con CSS applicato; API testate (lettura/scrittura/cancellazione) con curl.
3. Dati persistenti dopo riavvio.

## Vincoli
- Non cambiare stack o versioni senza chiedere.
- Non toccare: .env, *.db, package-lock.json.
