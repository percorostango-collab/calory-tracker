## Guardrail anti-errore (applicati anche da hook)

- Nuovo progetto o nuove dipendenze: usa la skill `safe-project-bootstrap`. Scaffolder ufficiale, versioni verificate con `npm view`, mai `package.json` scritto a memoria.
- Mai `--force`, `--legacy-peer-deps`, `npm audit fix --force`. Un conflitto di dipendenze si risolve scegliendo versioni compatibili.
- File esistenti: Read, poi Edit mirato. `Write` solo per file nuovi. Mai rimuovere `"use client"` o import esistenti.
- Config (`package.json`, `tsconfig`, `next/postcss/tailwind/drizzle.config`): modifiche minime; i pacchetti importati devono essere installati.
- Un solo dev server. Controlla le porte, avvia con run_in_background, termina solo il PID noto. Mai kill di tutti i node.
- Non eseguire `next build` mentre gira `next dev`.
- "Fatto/funziona" solo dopo output reale di tsc/build/test e controllo HTTP. L'hook Stop esegue la verifica: se fallisce, correggi la causa.
- Stesso errore, 2 tentativi falliti: fermati, riporta evidenze (errore completo, cosa hai provato) e chiedi.
- Non leggere né stampare `.env`. Non cancellare database, lockfile, `.git` senza richiesta esplicita.
