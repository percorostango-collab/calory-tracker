#!/usr/bin/env node
'use strict';
// Installer idempotente: copia hook/skill, fa il merge in settings.json (con backup), non tocca env/token/autoMode.
//   node install.js [--claude-dir "D:\ClaudeConfig\.claude"] [--dry-run] [--claude-md] [--plugins] [--uninstall]
const fs = require('fs');
const path = require('path');
const os = require('os');

const args = process.argv.slice(2);
const flag = (n) => args.includes(n);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
const dry = flag('--dry-run');

const claudeDir = opt('--claude-dir') || process.env.CLAUDE_CONFIG_DIR ||
  (fs.existsSync('D:\\ClaudeConfig\\.claude') ? 'D:\\ClaudeConfig\\.claude' : path.join(os.homedir(), '.claude'));
const settingsPath = path.join(claudeDir, 'settings.json');
const hooksDir = path.join(claudeDir, 'hooks');
const here = __dirname;
const HOOK_FILES = ['lib.js', 'guard-bash.js', 'guard-edit.js', 'post-edit-check.js', 'preflight.js', 'verify-stop.js'];

if (!fs.existsSync(settingsPath)) { console.error('settings.json non trovato in ' + claudeDir + ' (usa --claude-dir)'); process.exit(1); }
let s;
try { s = JSON.parse(fs.readFileSync(settingsPath, 'utf8').replace(/^\uFEFF/, '')); }
catch (e) { console.error('settings.json non è JSON valido: ' + e.message); process.exit(1); }

const log = [];
const fwd = (p) => p.replace(/\\/g, '/');
const cmdFor = (f) => 'node "' + fwd(hooksDir) + '/' + f + '"';

const wanted = [
  { event: 'PreToolUse', matcher: 'Bash|PowerShell', file: 'guard-bash.js', timeout: 30 },
  { event: 'PreToolUse', matcher: 'Write|Edit|MultiEdit', file: 'guard-edit.js', timeout: 120 },
  { event: 'PostToolUse', matcher: 'Write|Edit|MultiEdit', file: 'post-edit-check.js', timeout: 20 },
  { event: 'SessionStart', matcher: null, file: 'preflight.js', timeout: 20 },
  { event: 'Stop', matcher: null, file: 'verify-stop.js', timeout: 600 },
];

if (flag('--uninstall')) {
  for (const ev of Object.keys(s.hooks || {})) {
    s.hooks[ev] = s.hooks[ev].filter((g) => !(g.hooks || []).some((h) => HOOK_FILES.some((f) => f !== 'lib.js' && (h.command || '').includes('/hooks/' + f))));
    if (!s.hooks[ev].length) delete s.hooks[ev];
  }
  log.push('rimossi gli hook del pacchetto da settings.json (i file in hooks/ restano)');
} else {
  // 1) fix: autoCompactWindow era dentro extraKnownMarketplaces
  const m = s.extraKnownMarketplaces;
  if (m && Object.prototype.hasOwnProperty.call(m, 'autoCompactWindow')) {
    if (s.autoCompactWindow === undefined) s.autoCompactWindow = m.autoCompactWindow;
    delete m.autoCompactWindow;
    log.push('spostato autoCompactWindow da extraKnownMarketplaces al livello principale (era nel posto sbagliato)');
  }
  // 2) permessi
  s.permissions = s.permissions || {};
  s.permissions.deny = s.permissions.deny || [];
  for (const r of ['Read(**/.env)', 'Read(**/.env.*)', 'Bash(npm audit fix --force*)']) {
    if (!s.permissions.deny.includes(r)) { s.permissions.deny.push(r); log.push('permissions.deny += ' + r); }
  }
  // 3) hook (senza toccare quelli esistenti)
  s.hooks = s.hooks || {};
  for (const w of wanted) {
    const arr = (s.hooks[w.event] = s.hooks[w.event] || []);
    if (arr.some((g) => (g.hooks || []).some((h) => (h.command || '').includes('/hooks/' + w.file)))) continue;
    const g = { hooks: [{ type: 'command', command: cmdFor(w.file), timeout: w.timeout }] };
    if (w.matcher) g.matcher = w.matcher;
    arr.push(g);
    log.push('hook ' + w.event + (w.matcher ? '[' + w.matcher + ']' : '') + ' += ' + w.file);
  }
  // 4) plugin (opzionale)
  if (flag('--plugins') && s.enabledPlugins) {
    for (const k of ['ralph-loop@claude-plugins-official', 'marketing@knowledge-work-plugins']) {
      if (s.enabledPlugins[k] === true) { s.enabledPlugins[k] = false; log.push('plugin disattivato: ' + k); }
    }
  }
}

if (!dry) {
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  fs.copyFileSync(settingsPath, settingsPath + '.bak-' + stamp);
  if (!flag('--uninstall')) {
    fs.mkdirSync(hooksDir, { recursive: true });
    for (const f of HOOK_FILES) fs.copyFileSync(path.join(here, 'hooks', f), path.join(hooksDir, f));
    const sk = path.join(claudeDir, 'skills', 'safe-project-bootstrap');
    fs.mkdirSync(sk, { recursive: true });
    fs.copyFileSync(path.join(here, 'skills', 'safe-project-bootstrap', 'SKILL.md'), path.join(sk, 'SKILL.md'));
    log.push('copiati hook in ' + hooksDir + ' e skill safe-project-bootstrap');
    if (flag('--claude-md')) {
      const cm = path.join(claudeDir, 'CLAUDE.md');
      const add = fs.readFileSync(path.join(here, 'rules', 'CLAUDE.addendum.md'), 'utf8');
      const B = '<!-- BEGIN guardrails -->', E = '<!-- END guardrails -->';
      let cur = fs.existsSync(cm) ? fs.readFileSync(cm, 'utf8') : '';
      if (fs.existsSync(cm)) fs.copyFileSync(cm, cm + '.bak-' + stamp);
      const block = B + '\n' + add.trim() + '\n' + E;
      const i = cur.indexOf(B), j = cur.indexOf(E);
      cur = i >= 0 && j > i ? cur.slice(0, i) + block + cur.slice(j + E.length) : cur.replace(/\s*$/, '\n\n') + block + '\n';
      fs.writeFileSync(cm, cur);
      log.push('regole aggiunte/aggiornate in ' + cm);
    }
  }
  fs.writeFileSync(settingsPath, JSON.stringify(s, null, 2) + '\n');
}
console.log((dry ? '[DRY-RUN] ' : '') + 'cartella Claude: ' + claudeDir);
console.log(log.length ? log.map((l) => ' - ' + l).join('\n') : ' - nessuna modifica necessaria (già installato)');
if (!dry) console.log('Backup di settings.json creato. RIAVVIA Claude Code per attivare gli hook.');
