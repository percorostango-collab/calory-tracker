'use strict';
// Stop: se in questo turno sono state fatte modifiche, esegue verifiche REALI e blocca la
// chiusura finché falliscono (max 3 blocchi, poi lascia chiudere e avvisa l'utente).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { readInput, readJson, run, runArgs, tailText, openPorts } = require('./lib');

const MAX_BLOCKS = 3;
const EDIT_TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit']);

function editedThisTurn(tp) {
  try {
    if (!tp || !fs.existsSync(tp)) return true;
    const lines = fs.readFileSync(tp, 'utf8').split('\n').filter(Boolean);
    for (let i = lines.length - 1; i >= 0; i--) {
      let o; try { o = JSON.parse(lines[i]); } catch (e) { continue; }
      const content = o.message && o.message.content;
      if (o.type === 'user') {
        const isResult = Array.isArray(content) && content.some((c) => c && c.type === 'tool_result');
        if (!isResult && !o.isMeta) return false; // inizio del turno corrente
        continue;
      }
      if (o.type === 'assistant' && Array.isArray(content)) {
        for (const c of content) {
          if (!c || c.type !== 'tool_use') continue;
          if (EDIT_TOOLS.has(c.name)) return true;
          if (/^(Bash|PowerShell)$/.test(c.name) &&
              /\bnpm\s+(i|install|add|uninstall|remove|rm)\b|\bgit\s+(checkout|restore|reset)\b|\bnpx\s+create/i.test((c.input || {}).command || '')) return true;
        }
      }
    }
    return false;
  } catch (e) { return true; }
}

async function get(url) {
  const r = await fetch(url, { signal: AbortSignal.timeout(15000) });
  return { status: r.status, headers: r.headers, body: await r.text() };
}

async function probeWebServer(port, hasTailwind) {
  const base = 'http://localhost:' + port;
  let r;
  try { r = await get(base + '/'); } catch (e) { return { relevant: false }; }
  const isNext = /next\.js/i.test(r.headers.get('x-powered-by') || '') || r.body.includes('/_next/');
  const isVite = r.body.includes('/@vite/client');
  if (!isNext && !isVite) return { relevant: false };
  const problems = [];
  if (r.status >= 500 || r.body.includes('id="__next_error__"')) problems.push('GET / -> HTTP ' + r.status + ' (pagina in errore)');
  if (r.body.includes('This page could not be found')) problems.push('GET / mostra la pagina 404 (la route principale non esiste o non compila)');
  const links = (r.body.match(/<link[^>]*rel="stylesheet"[^>]*>/g) || []).map((l) => (l.match(/href="([^"]+)"/) || [])[1]).filter(Boolean);
  let css = '';
  for (const h of links.slice(0, 5)) {
    try {
      const rr = await get(new URL(h, base).href);
      if (rr.status !== 200) problems.push('CSS ' + h + ' -> HTTP ' + rr.status); else css += rr.body;
    } catch (e) { problems.push('CSS ' + h + ' non raggiungibile'); }
  }
  if (hasTailwind && css) {
    const tokens = new Set();
    for (const m of r.body.matchAll(/class="([^"]*)"/g)) {
      for (const t of m[1].split(/\s+/)) if (/^[a-z][a-z0-9-]*$/.test(t) && t !== 'group' && t !== 'peer') tokens.add(t);
    }
    const missing = [...tokens].filter((t) => !css.includes('.' + t));
    if (tokens.size >= 6 && missing.length >= 3) {
      problems.push('classi usate nell\'HTML ma assenti nel CSS compilato: ' + missing.slice(0, 10).join(', ') + ' (con Tailwind v4 colori come bg-card/text-foreground vanno dichiarati in @theme; oppure PostCSS non compila)');
    }
  }
  return { relevant: true, port, problems };
}

(async () => {
  if (process.env.CLAUDE_GUARD_OFF === '1') return;
  const input = readInput();
  const cwd = input.cwd || process.cwd();
  const sid = String(input.session_id || 'nosession').replace(/[^\w-]/g, '');
  const stateFile = path.join(os.tmpdir(), 'claude-verify-' + sid + '.json');
  let st = { count: 0, ts: 0, failing: false };
  try { st = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (e) {}
  if (Date.now() - st.ts > 20 * 60 * 1000) st = { count: 0, ts: 0, failing: false };
  const save = (o) => { try { fs.writeFileSync(stateFile, JSON.stringify(o)); } catch (e) {} };

  if (!editedThisTurn(input.transcript_path) && !st.failing) return;

  const cfg = readJson(path.join(cwd, '.claude', 'verify.json')) || {};
  const skip = new Set(cfg.skip || []);
  const results = [];
  const warns = [];
  const add = (name, ok, detail) => results.push({ name, ok, detail: ok ? '' : detail });

  const pkg = readJson(path.join(cwd, 'package.json'));
  if (pkg) {
    const deps = Object.assign({}, pkg.dependencies, pkg.devDependencies);
    const scripts = pkg.scripts || {};
    const hasModules = fs.existsSync(path.join(cwd, 'node_modules'));
    if (!skip.has('tsc') && hasModules && deps.typescript && fs.existsSync(path.join(cwd, 'tsconfig.json'))) {
      const r = run('npx --no-install tsc --noEmit --incremental false', cwd, 150000);
      add('tsc --noEmit', r.code === 0, r.timedOut ? 'timeout' : tailText(r.out, 2500));
    }
    const ports = await openPorts(3000, 3010);
    const webPorts = [];
    if (!skip.has('http') && scripts.dev) {
      for (const p of ports) {
        const pr = await probeWebServer(p, !!deps.tailwindcss && !skip.has('css'));
        if (!pr.relevant) continue;
        webPorts.push(p);
        add('server dev porta ' + p, pr.problems.length === 0, pr.problems.join('\n'));
      }
      if (webPorts.length > 1) warns.push('più server web attivi (porte ' + webPorts.join(', ') + '): ne serve uno solo, termina gli altri per PID.');
    }
    if (!skip.has('build') && hasModules && scripts.build && webPorts.length === 0) {
      const r = run('npm run build', cwd, 240000);
      add('npm run build', r.code === 0, r.timedOut ? 'timeout' : tailText(r.out, 3000));
    } else if (webPorts.length && scripts.build) {
      warns.push('build saltata perché un dev server è attivo (un build concorrente corrompe .next).');
    }
    if (!skip.has('tests') && hasModules && scripts.test && !/no test specified/i.test(scripts.test)) {
      process.env.CI = '1';
      const r = run('npm test', cwd, 120000);
      add('npm test', r.code === 0, r.timedOut ? 'timeout' : tailText(r.out, 2500));
    }
  } else if (!skip.has('python')) {
    const g = run('git status --porcelain', cwd, 8000);
    if (g.code === 0) {
      const files = g.out.split('\n').map((l) => l.slice(3).trim().replace(/^"|"$/g, '')).filter((f) => f.endsWith('.py') && fs.existsSync(path.join(cwd, f)));
      const code = 'import ast,sys\nfor f in sys.argv[1:]:\n    ast.parse(open(f,encoding="utf-8").read(),f)';
      if (files.length) {
        let r = runArgs('python', ['-c', code].concat(files), cwd, 60000);
        if (r.missing) r = runArgs('python3', ['-c', code].concat(files), cwd, 60000);
        if (!r.missing) add('sintassi Python (' + files.length + ' file modificati)', r.code === 0, tailText(r.out, 2000));
      }
    }
  }

  for (const c of cfg.commands || []) {
    const r = run(c.cmd, cwd, (c.timeoutSec || 120) * 1000);
    add(c.name || c.cmd, r.code === 0, r.timedOut ? 'timeout' : tailText(r.out, 2500));
  }
  for (const u of cfg.urls || []) {
    try {
      const r = await get(u.url);
      const okStatus = r.status === (u.status || 200);
      const okBody = !u.contains || r.body.includes(u.contains);
      add('GET ' + u.url, okStatus && okBody, 'HTTP ' + r.status + (okBody ? '' : ', manca il testo atteso "' + u.contains + '"'));
    } catch (e) { add('GET ' + u.url, false, 'non raggiungibile: ' + e.message); }
  }

  if (!results.length) return;
  const failed = results.filter((r) => !r.ok);
  if (!failed.length) {
    save({ count: 0, ts: Date.now(), failing: false });
    process.stdout.write(JSON.stringify({ systemMessage: '✓ Verifica automatica OK: ' + results.map((r) => r.name).join(', ') + (warns.length ? ' | ATTENZIONE: ' + warns.join(' ') : '') }));
    return;
  }

  st.count = (st.count || 0) + 1; st.ts = Date.now(); st.failing = true;
  const body = failed.map((f) => '[' + f.name + ']\n' + f.detail).join('\n\n');
  if (st.count > MAX_BLOCKS) {
    save({ count: 0, ts: Date.now(), failing: false });
    process.stdout.write(JSON.stringify({ systemMessage: '⚠ Verifica automatica ancora FALLITA dopo ' + MAX_BLOCKS + ' tentativi: il lavoro NON è verificato.\n' + body }));
    return;
  }
  save(st);
  process.stdout.write(JSON.stringify({
    decision: 'block',
    reason: 'VERIFICA AUTOMATICA FALLITA (tentativo ' + st.count + '/' + MAX_BLOCKS + '). Non dichiarare il lavoro completato. Errori reali:\n\n' + body +
      '\n\nCorreggi la CAUSA di questi errori (non ripetere fix già falliti, non riscrivere file interi). La verifica ripartirà da sola. ' +
      'Se dopo 2 tentativi sullo stesso errore non è risolto, fermati e riporta all\'utente cosa hai provato.' + (warns.length ? '\nAvvisi: ' + warns.join(' ') : ''),
  }));
})();
