'use strict';
// SessionStart: inventario del progetto iniettato nel contesto prima che l'agente tocchi qualcosa.
const fs = require('fs');
const path = require('path');
const { readInput, readJson, run, openPorts, pidOfPort } = require('./lib');

(async () => {
  const input = readInput();
  const cwd = input.cwd || process.cwd();
  const L = [];
  const npmv = run('npm --version', cwd, 8000).out.trim().split('\n').pop();
  L.push('[PREFLIGHT] ' + process.platform + ' | node ' + process.version + ' | npm ' + npmv + ' | cwd ' + cwd);

  let entries = [];
  try { entries = fs.readdirSync(cwd); } catch (e) {}
  const ignorable = new Set(['.git', '.claude', 'CLAUDE.md', '.gitignore', '.env', '.agent-state', 'DEBUG_LOG.md', 'PROJECT_STATE.md']);
  if (!entries.filter((e) => !ignorable.has(e)).length) {
    L.push('Cartella vuota/nuova: usa lo scaffolder ufficiale (es. create-next-app) e versioni verificate con `npm view`; non scrivere package.json a mano.');
  }

  const pkg = readJson(path.join(cwd, 'package.json'));
  if (pkg) {
    const deps = Object.assign({}, pkg.dependencies, pkg.devDependencies);
    const key = ['next', 'react', 'react-dom', 'tailwindcss', 'typescript', 'drizzle-orm', 'prisma', '@libsql/client', 'better-sqlite3', 'vite'];
    L.push('package.json: ' + (pkg.name || '?') + ' | scripts: ' + Object.keys(pkg.scripts || {}).join(', '));
    L.push('versioni: ' + (key.filter((k) => deps[k]).map((k) => k + '@' + deps[k]).join(', ') || 'nessuna chiave'));
    const lock = ['package-lock.json', 'pnpm-lock.yaml', 'yarn.lock'].filter((x) => fs.existsSync(path.join(cwd, x)));
    L.push('lockfile: ' + (lock.join(', ') || 'ASSENTE') + ' | node_modules: ' + (fs.existsSync(path.join(cwd, 'node_modules')) ? 'sì' : 'NO (serve npm install)'));
    const native = ['better-sqlite3', 'sqlite3', 'sharp', 'bcrypt', 'canvas', 'node-sass'].filter((k) => deps[k]);
    if (native.length && process.platform === 'win32') {
      L.push('ATTENZIONE moduli nativi su Windows (' + native.join(', ') + '): richiedono prebuilt per Node ' + process.version + ' o toolchain C++. Preferisci alternative pure-JS (@libsql/client, bcryptjs).');
    }
  } else if (['requirements.txt', 'pyproject.toml'].some((x) => fs.existsSync(path.join(cwd, x)))) {
    L.push('progetto Python (requirements/pyproject presenti).');
  }

  const dbs = entries.filter((e) => /\.(db|sqlite3?)$/i.test(e));
  if (dbs.length) L.push('database locali (dati utente, NON cancellare): ' + dbs.join(', '));
  if (entries.includes('.env')) L.push('.env presente (contiene segreti: non leggerlo né stamparlo).');

  const open = await openPorts(3000, 3010);
  if (open.length) L.push('porte in ascolto 3000-3010: ' + open.map((p) => p + (pidOfPort(p) ? ' (PID ' + pidOfPort(p) + ')' : '')).join(', ') + ' -> non avviare un secondo dev server.');

  L.push('REGOLE ATTIVE (hook): versioni npm verificate; niente --force; niente kill di tutti i node; config che importano pacchetti assenti bloccate; riscritture troncate bloccate; a fine lavoro parte la verifica automatica (tsc/build/HTTP/test): non dichiarare "funziona" prima che passi. Dopo 2 fix falliti sullo stesso errore: fermati e riporta.');
  process.stdout.write(L.join('\n') + '\n');
})();
