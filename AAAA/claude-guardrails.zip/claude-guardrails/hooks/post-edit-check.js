'use strict';
// PostToolUse (Write|Edit|MultiEdit): controllo rapido del file appena scritto.
// Exit 2 = il messaggio su stderr viene mostrato a Claude come feedback.
const fs = require('fs');
const path = require('path');
const { readInput, runArgs } = require('./lib');

if (process.env.CLAUDE_GUARD_OFF === '1') process.exit(0);
const input = readInput();
const f = (input.tool_input || {}).file_path;
if (!f) process.exit(0);
const abs = path.resolve(input.cwd || process.cwd(), f);
if (!fs.existsSync(abs)) process.exit(0);
const norm = abs.replace(/\\/g, '/');
const ext = path.extname(abs).toLowerCase();
const base = path.basename(abs);
let txt = '';
try { txt = fs.readFileSync(abs, 'utf8'); } catch (e) { process.exit(0); }
const issues = [];

if (ext === '.json' && !/^(tsconfig|jsconfig)/i.test(base) && !/\/\.vscode\//.test(norm)) {
  try { JSON.parse(txt.replace(/^\uFEFF/, '')); } catch (e) { issues.push('JSON non valido: ' + e.message); }
}

if (ext === '.tsx' || ext === '.jsx') {
  const hooks = ['useState', 'useEffect', 'useRef', 'useMemo', 'useCallback', 'useReducer', 'useContext'];
  const used = hooks.filter((h) => new RegExp('(^|[^\\w.])' + h + '\\s*\\(').test(txt));
  const notImported = used.filter((h) => !new RegExp('import[^;]*\\b' + h + '\\b').test(txt));
  if (notImported.length) issues.push('usa ' + notImported.join(', ') + ' senza importarli da "react" (ReferenceError a runtime; il file potrebbe essere stato riscritto incompleto).');
  const hasUC = /['"]use client['"]/.test(txt.slice(0, 300));
  if (used.length && !hasUC && /\/(app|components)\//.test(norm)) {
    issues.push('usa hook React ma manca "use client" in cima al file (errore di build in Next.js App Router, a meno che sia importato solo da client component).');
  }
}

if (ext === '.py') {
  const code = 'import ast,sys;ast.parse(open(sys.argv[1],encoding="utf-8").read())';
  let r = runArgs('python', ['-c', code, abs], undefined, 15000);
  if (r.missing) r = runArgs('python3', ['-c', code, abs], undefined, 15000);
  if (!r.missing && r.code !== 0) issues.push('errore di sintassi Python:\n' + r.out.trim().split('\n').slice(-4).join('\n'));
}

if (issues.length) {
  process.stderr.write('CONTROLLO POST-MODIFICA su ' + base + ':\n- ' + issues.join('\n- ') + '\nCorreggi prima di proseguire.\n');
  process.exit(2);
}
