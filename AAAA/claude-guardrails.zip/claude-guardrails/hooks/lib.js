'use strict';
// Utility condivise dagli hook. Solo moduli standard di Node (>=18).
const fs = require('fs');
const path = require('path');
const net = require('net');
const { spawnSync } = require('child_process');

function readInput() {
  try {
    const raw = fs.readFileSync(0, 'utf8');
    return raw && raw.trim() ? JSON.parse(raw) : {};
  } catch (e) { return {}; }
}

function readJson(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { return null; }
}

function run(cmd, cwd, timeoutMs) {
  const r = spawnSync(cmd, {
    cwd, shell: true, encoding: 'utf8', timeout: timeoutMs || 60000,
    windowsHide: true, maxBuffer: 50 * 1024 * 1024, env: process.env,
  });
  return { code: r.status, out: (r.stdout || '') + (r.stderr || ''), timedOut: !!(r.error && r.error.code === 'ETIMEDOUT') };
}

function runArgs(bin, args, cwd, timeoutMs) {
  const r = spawnSync(bin, args, { cwd, encoding: 'utf8', timeout: timeoutMs || 30000, windowsHide: true });
  return {
    code: r.status, out: (r.stdout || '') + (r.stderr || ''),
    missing: !!(r.error && r.error.code === 'ENOENT'), timedOut: !!(r.error && r.error.code === 'ETIMEDOUT'),
  };
}

function tailText(s, max) {
  s = String(s || '').trim();
  return s.length > max ? '…' + s.slice(-max) : s;
}

// Risposta PreToolUse: decision = 'deny' | 'ask'
function pre(decision, reason) {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: decision, permissionDecisionReason: reason },
  }));
}

function portOpen(port, host, ms) {
  return new Promise((resolve) => {
    const s = net.connect({ port, host: host || 'localhost' });
    const done = (v) => { try { s.destroy(); } catch (e) {} resolve(v); };
    s.setTimeout(ms || 300, () => done(false));
    s.once('connect', () => done(true));
    s.once('error', () => done(false));
  });
}

async function openPorts(from, to) {
  const jobs = [];
  for (let p = from; p <= to; p++) jobs.push(portOpen(p).then((o) => (o ? p : null)));
  return (await Promise.all(jobs)).filter(Boolean);
}

function pidOfPort(port) {
  if (process.platform !== 'win32') return null;
  const r = run('netstat -ano -p tcp', undefined, 8000);
  const m = r.out.match(new RegExp(':' + port + '\\s+\\S+\\s+LISTENING\\s+(\\d+)', 'i'));
  return m ? m[1] : null;
}

// true = esiste, false = NON esiste, null = non verificabile (rete assente, tag, spec strana)
function versionExists(name, spec) {
  if (!/^[@\w./-]+$/.test(name)) return null;
  if (!/^[\^~>=<\s]*\d/.test(spec) || !/^[\w.^~<>=| *-]+$/.test(spec)) return null;
  const r = run('npm view "' + name + '@' + spec + '" version', undefined, 20000);
  if (r.timedOut) return null;
  if (r.code === 0) return r.out.trim() !== '';
  if (/E404|ETARGET|notarget|No match found/i.test(r.out)) return false;
  return null;
}

function findProjectRoot(file) {
  let d = path.dirname(file);
  for (;;) {
    if (fs.existsSync(path.join(d, 'package.json'))) return d;
    const p = path.dirname(d);
    if (p === d) return null;
    d = p;
  }
}

module.exports = { readInput, readJson, run, runArgs, tailText, pre, portOpen, openPorts, pidOfPort, versionExists, findProjectRoot };
