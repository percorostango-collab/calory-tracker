'use strict';
// PreToolUse (Bash|PowerShell): blocca i comandi che hanno causato i disastri osservati.
const { readInput, pre, openPorts, pidOfPort, versionExists } = require('./lib');

(async () => {
  if (process.env.CLAUDE_GUARD_OFF === '1') return;
  const input = readInput();
  const cmd = String((input.tool_input || {}).command || '');
  if (!cmd.trim()) return;
  const c = cmd.replace(/\s+/g, ' ');

  const rules = [
    ['deny', /\b(npm|pnpm|yarn)\b[^;&|\n]*\b(install|i|add|ci|update|upgrade)\b[^;&|\n]*(--force|--legacy-peer-deps|\s-f\b)/i,
      'Vietato --force / --legacy-peer-deps: nasconde il conflitto invece di risolverlo. Leggi l\'errore ERESOLVE, controlla i peer con `npm view <pkg>@<ver> peerDependencies` e scegli versioni compatibili. Se serve davvero, chiedi all\'utente.'],
    ['deny', /\bnpm\s+audit\s+fix\b[^;&|\n]*--force/i,
      'Vietato `npm audit fix --force`: fa upgrade major non richiesti e rompe il progetto.'],
    ['deny', /Get-Process[^|;\n]*node[^|;\n]*\|\s*Stop-Process|Stop-Process[^;\n]*-Name\s+['"]?node|taskkill[^;\n]*\/im\s+['"]?node|\b(pkill|killall)\s+(-\S+\s+)?node/i,
      'Vietato terminare TUTTI i processi node (colpisce anche altri progetti). Trova il PID sulla porta (`netstat -ano | findstr :3000`) e termina solo quello con `taskkill /PID <pid> /F`.'],
    ['deny', /\b(npm\s+run\s+dev|npm\s+(run\s+)?start|next\s+dev|npx\s+next\s+dev|vite)\b[^|;\n]*[^&]&\s*$/i,
      'Non avviare il dev server con `&`: muore con la shell e lascia processi zombie. Usa l\'esecuzione in background del tool Bash (run_in_background) e leggi l\'output del task.'],
    ['deny', /\bgit\s+reset\s+--hard|\bgit\s+clean\s+-\w*f|\bgit\s+push\b[^;&|\n]*(--force|\s-f\b)/i,
      'Comando git distruttivo: serve conferma esplicita dell\'utente nel messaggio, non dell\'agente.'],
    ['deny', /\brm\s+(-\w+\s+)*-\w*[rf]\w*\s+(\/|~|\*|\.\.?|[A-Za-z]:[\\/]?)(\s|$)/i,
      'Cancellazione troppo ampia (root, home, drive, `*`, `.`, `..`). Specifica il percorso esatto.'],
    ['deny', /\b(cat|type|Get-Content|gc|more|head|tail)\b[^;&|\n]*\.env(?!\.example|\.sample|\.template)\b/i,
      'Non stampare .env: contiene segreti che finirebbero nel contesto del modello. Verifica solo che le variabili esistano, senza mostrarne il valore.'],
    ['ask', /\b(rm|del|erase|rmdir|rd|Remove-Item|ri)\b[^;&|\n]*(package-lock\.json|(^|[\s\/\\'"])\.git([\s\/\\'"]|$)|(^|[\s\/\\'"])\.env\b|\.(db|sqlite3?)\b)/i,
      'Stai per cancellare lockfile, .git, .env o un database (dati dell\'utente). Conferma.'],
    ['ask', /\bgit\s+(commit|push|tag|rebase|merge|stash\s+(drop|clear)|branch\s+-D|checkout\s+(--\s+)?\.(\s|$)|restore\s+\.(\s|$))/i,
      'Operazione git con effetti persistenti: conferma (le regole globali vietano commit/push non richiesti).'],
    ['ask', /(curl|wget|irm|iwr|Invoke-RestMethod|Invoke-WebRequest)[^\n]*\|\s*(bash|sh|iex|Invoke-Expression)/i,
      'Esecuzione di script scaricati dalla rete (pipe in shell): conferma dopo averne ispezionato il contenuto.'],
  ];
  for (const [decision, re, msg] of rules) {
    if (re.test(c)) return pre(decision, msg);
  }

  // Avvio dev server con porta già occupata -> evita server multipli/zombie
  if (/\b(npm\s+run\s+dev|npm\s+(run\s+)?start|next\s+dev|npx\s+next\s+dev)\b/i.test(c) && !/\s-p\s*\d+|--port/i.test(c)) {
    const open = await openPorts(3000, 3005);
    if (open.length) {
      const det = open.map((p) => 'porta ' + p + (pidOfPort(p) ? ' (PID ' + pidOfPort(p) + ')' : '')).join(', ');
      return pre('deny', 'Un server risulta già in ascolto: ' + det + '. Non avviarne un secondo (Next passerebbe a una porta diversa e l\'utente guarderebbe quello vecchio). Riusa quello esistente; se serve riavviarlo, termina SOLO quel PID con `taskkill /PID <pid> /F` in un comando separato, poi avvia.');
    }
  }

  // npm install pkg@versione -> la versione deve esistere davvero
  const bad = [];
  for (const seg of c.split(/&&|;|\|\|?/)) {
    const m = seg.trim().match(/^(?:npm|pnpm)\s+(?:install|i|add)\s+(.*)$/i) || seg.trim().match(/^yarn\s+add\s+(.*)$/i);
    if (!m) continue;
    for (let t of m[1].split(' ')) {
      t = t.replace(/^['"]|['"]$/g, '');
      if (!t || t.startsWith('-')) continue;
      const mm = t.match(/^(@?[^@\s]+)@(.+)$/);
      if (mm && versionExists(mm[1], mm[2]) === false) bad.push(t);
    }
  }
  if (bad.length) {
    return pre('deny', 'Versione/pacchetto inesistente nel registry npm: ' + bad.join(', ') + '. Non indovinare: usa `npm view <pkg> versions --json` (o `npm view <pkg> version`) e scegli una versione reale e compatibile.');
  }
})();
