'use strict';
// PreToolUse (Write|Edit|MultiEdit): impedisce sovrascritture troncate, config con
// import/plugin non installati, versioni npm inventate e modifiche a segreti/lockfile.
const fs = require('fs');
const path = require('path');
const { readInput, pre, versionExists, findProjectRoot } = require('./lib');

const CONFIG_RE = /^(package\.json|tsconfig(\..+)?\.json|next\.config\.\w+|postcss\.config\.\w+|tailwind\.config\.\w+|drizzle\.config\.\w+|eslint\.config\.\w+|\.eslintrc(\..+)?|vite\.config\.\w+|webpack\.config\.\w+|babel\.config\.\w+)$/i;
const IMPORT_CHECK_RE = /^((postcss|next|tailwind|drizzle|eslint|vite|webpack|babel|jest|vitest|playwright|prettier)\.config\.\w+|\.eslintrc(\..+)?)$/i;
const SKIP_KEYS = new Set(['name', 'version', 'node', 'npm', 'type', 'main', 'module']);
const builtin = new Set(require('module').builtinModules);

function bareImports(text, isPostcss) {
  const out = new Set();
  const re = /(?:from\s+|import\s*\(\s*|import\s+|require\s*\(\s*)['"]([^'"\n]+)['"]/g;
  let m;
  while ((m = re.exec(text))) out.add(m[1]);
  if (isPostcss) {
    const re2 = /['"]((?:@[\w.-]+\/)?[\w.-]+)['"]\s*:\s*[\{\[]/g;
    while ((m = re2.exec(text))) out.add(m[1]);
  }
  return [...out].filter((s) => !/^(\.|\/|node:|#|@\/|~\/|data:|https?:)/.test(s) && !builtin.has(s.split('/')[0]));
}
const pkgName = (s) => (s.startsWith('@') ? s.split('/').slice(0, 2).join('/') : s.split('/')[0]);

(async () => {
  if (process.env.CLAUDE_GUARD_OFF === '1') return;
  const input = readInput();
  const tool = input.tool_name;
  const ti = input.tool_input || {};
  if (!ti.file_path) return;
  const abs = path.resolve(input.cwd || process.cwd(), ti.file_path);
  const base = path.basename(abs);
  const exists = fs.existsSync(abs);
  const isWrite = tool === 'Write';
  const newText = isWrite ? String(ti.content || '')
    : tool === 'MultiEdit' ? (ti.edits || []).map((e) => e.new_string || '').join('\n')
    : String(ti.new_string || '');

  if (/^\.env(\..*)?$/.test(base) && !/\.(example|sample|template)$/.test(base)) {
    return pre('ask', 'Stai modificando un file di segreti (' + base + '). Conferma; non scrivere chiavi reali in chiaro nella chat.');
  }
  if (base === 'package-lock.json') {
    return pre('deny', 'Non modificare package-lock.json a mano: si rigenera con npm install.');
  }

  if (isWrite && exists) {
    let old = '';
    try { old = fs.readFileSync(abs, 'utf8'); } catch (e) {}
    const hadUC = /['"]use client['"]/.test(old.slice(0, 300));
    const hasUC = /['"]use client['"]/.test(newText.slice(0, 300));
    if (hadUC && !hasUC) {
      return pre('deny', 'Il file esistente iniziava con "use client" e la tua riscrittura no: si romperebbe in Next.js. Rileggi il file e usa Edit per modifiche mirate.');
    }
    if (old.length >= 600 && newText.length < old.length * 0.5) {
      return pre('ask', 'Riscrittura sospetta di ' + base + ': il nuovo contenuto è ' + Math.round(100 * newText.length / old.length) + '% del file esistente (' + old.length + ' → ' + newText.length + ' caratteri). Probabile file troncato. Leggi il file e usa Edit; se è voluto, conferma.');
    }
    if (CONFIG_RE.test(base)) {
      return pre('ask', 'Sovrascrittura completa del file di configurazione esistente ' + base + '. Preferisci Edit mirato; conferma se è davvero necessario.');
    }
  }

  if (base === 'package.json') {
    const pairs = [];
    if (isWrite) {
      try {
        const j = JSON.parse(newText);
        for (const k of ['dependencies', 'devDependencies', 'peerDependencies', 'optionalDependencies']) {
          for (const [n, v] of Object.entries(j[k] || {})) pairs.push([n, String(v)]);
        }
      } catch (e) {
        return pre('deny', 'package.json non è JSON valido: ' + e.message);
      }
    } else {
      const re = /"(@?[\w./-]+)"\s*:\s*"([\^~]?\d[^"]*)"/g;
      let m;
      while ((m = re.exec(newText))) if (!SKIP_KEYS.has(m[1])) pairs.push([m[1], m[2]]);
    }
    const bad = [];
    for (const [n, v] of pairs.slice(0, 25)) if (versionExists(n, v) === false) bad.push(n + '@' + v);
    if (bad.length) {
      return pre('deny', 'Versioni inesistenti nel registry npm: ' + bad.join(', ') + '. Non indovinare: `npm view <pkg> versions --json`. Meglio ancora: scaffolding ufficiale (create-next-app) invece di scrivere package.json a mano.');
    }
  }

  if (IMPORT_CHECK_RE.test(base)) {
    const root = findProjectRoot(abs);
    if (root && fs.existsSync(path.join(root, 'node_modules'))) {
      const missing = bareImports(newText, /^postcss\.config/i.test(base))
        .map(pkgName)
        .filter((p, i, a) => a.indexOf(p) === i)
        .filter((p) => !fs.existsSync(path.join(root, 'node_modules', p)));
      if (missing.length) {
        return pre('deny', base + ' usa pacchetti NON installati: ' + missing.join(', ') + '. Non scrivere config che dipendono da pacchetti assenti: verifica la versione (`npm view`), installali e poi scrivi il file; oppure togli l\'import (es. con Tailwind v4 serve solo @tailwindcss/postcss, non autoprefixer).');
      }
    }
  }
})();
