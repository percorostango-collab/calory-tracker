---
name: safe-project-bootstrap
description: Usare quando si crea un nuovo progetto da zero o si aggiungono dipendenze/configurazioni (Next.js, Node, Tailwind, ORM, database locale), soprattutto su Windows. Impone scaffolding ufficiale, versioni verificate, verifica reale prima di dichiarare "fatto" e stop dopo due fix falliti.
---

# Avvio sicuro di un progetto

Segui in ordine. Non saltare passaggi e non dichiarare completato nulla che non abbia un output reale.

## 1. Prima di scrivere codice
1. Esegui `node -v`, `npm -v` e ispeziona la cartella (il preflight dell'hook lo fa già: leggilo).
2. Elenca in 5 righe: stack, versioni scelte, database, come verificherai il risultato. Se l'utente ha già un piano, seguilo alla lettera e non cambiare stack senza chiedere.

## 2. Scaffolding
- Usa lo scaffolder ufficiale (`npx create-next-app@latest`, `npm create vite@latest`...) invece di scrivere `package.json`, `tsconfig.json`, `next.config`, `postcss.config` a mano.
- Se la cartella contiene già file (.env, .gitignore, CLAUDE.md), scaffolda in una sottocartella temporanea e sposta i file, senza sovrascrivere nulla.

## 3. Dipendenze
- Ogni pacchetto: `npm view <pkg> version` e, se serve una versione precisa, `npm view <pkg>@<ver> peerDependencies`. Mai versioni a memoria.
- Mai `--force` / `--legacy-peer-deps`. Un ERESOLVE si risolve scegliendo versioni compatibili.
- Windows: evita moduli nativi da compilare (better-sqlite3, sharp, bcrypt...) se non esiste un prebuilt per la versione di Node in uso. Preferisci `@libsql/client`, `bcryptjs`.
- Tailwind v4: serve solo `@tailwindcss/postcss` in `postcss.config.mjs` (`plugins: {"@tailwindcss/postcss": {}}`), niente autoprefixer. Colori semantici (bg-card, text-foreground...) vanno dichiarati in `@theme`.

## 4. Scrittura dei file
- File esistente: leggi, poi `Edit` mirato. `Write` solo per file nuovi.
- Un componente con hook React deve avere `"use client"` e gli import da "react".
- Un solo dev server: controlla le porte prima di avviarlo; avvialo con run_in_background; termina solo il PID che hai avviato.

## 5. Verifica (obbligatoria)
- `npx tsc --noEmit` e, se non c'è un dev server attivo, `npm run build` (mai build mentre gira `next dev`: corrompe `.next`).
- Con il server attivo: GET `/` = 200, CSS = 200, e per ogni API `curl` di un caso reale (lettura, scrittura, cancellazione).
- Per UI: controlla con il browser (plugin playwright) layout e interazioni principali, non solo l'HTML.
- Riporta cosa hai eseguito e l'esito reale. Se non l'hai eseguito, scrivi "non verificato".

## 6. Quando qualcosa fallisce
- Leggi l'errore completo prima di modificare qualsiasi cosa.
- Registra il tentativo in `DEBUG_LOG.md` (errore, file, modifica, esito).
- Massimo 2 tentativi sulla stessa causa. Al terzo: fermati, riporta evidenze e ipotesi, chiedi indicazioni.
- Non riscrivere file interi per correggere un dettaglio; non cancellare cache/lockfile/db senza una causa documentata.
