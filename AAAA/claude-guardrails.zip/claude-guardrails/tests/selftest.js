'use strict';
// node tests/selftest.js  -> prova ogni hook con input finti e stampa PASS/FAIL/SKIP.
const { spawnSync, execSync } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const H = (f) => path.join(__dirname, '..', 'hooks', f);
let fails = 0;

function hook(file, input, cwd) {
  const r = spawnSync('node', [H(file)], { input: JSON.stringify(input), encoding: 'utf8', cwd: cwd || os.tmpdir() });
  return { code: r.status, out: (r.stdout || '').trim(), err: (r.stderr || '').trim() };
}
const decision = (o) => { try { return JSON.parse(o.out).hookSpecificOutput.permissionDecision; } catch (e) { return o.out ? 'other' : 'allow'; } };
function check(name, ok, extra) { if (!ok) fails++; console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok ? '' : '  -> ' + (extra || ''))); }
const bash = (command) => decision(hook('guard-bash.js', { tool_name: 'Bash', tool_input: { command }, cwd: os.tmpdir() }));

// rete disponibile?
const net = spawnSync('npm', ['view', 'npm', 'version'], { shell: true, encoding: 'utf8' }).status === 0;

console.log('== guard-bash ==');
check('npm install --force -> deny', bash('npm install --force') === 'deny');
check('npm i x --legacy-peer-deps -> deny', bash('npm i foo --legacy-peer-deps') === 'deny');
check('npm audit fix --force -> deny', bash('npm audit fix --force') === 'deny');
check('Get-Process node | Stop-Process -> deny', bash('Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force') === 'deny');
check('taskkill /im node.exe -> deny', bash('taskkill /F /IM node.exe') === 'deny');
check('npm run dev & -> deny', bash('npm run dev &') === 'deny');
check('git reset --hard -> deny', bash('git reset --hard HEAD~1') === 'deny');
check('git commit -> ask', bash('git commit -m "x"') === 'ask');
check('cat .env -> deny', bash('cat .env') === 'deny');
check('cat .env.example -> allow', bash('cat .env.example') === 'allow');
check('rm package-lock.json -> ask', bash('rm package-lock.json') === 'ask');
check('rm -rf .next -> allow', bash('rm -rf .next') === 'allow');
check('ls -la -> allow', bash('ls -la') === 'allow');
check('npm run dev && echo -> not blocked as background', bash('npm run build && echo done') === 'allow');
if (net) {
  check('npm i drizzle-kit@^0.24.3 -> deny (versione inesistente)', bash('npm install drizzle-kit@^0.24.3') === 'deny');
  check('npm i @types/better-sqlite3@^8.3.0 -> deny', bash('npm install -D @types/better-sqlite3@^8.3.0') === 'deny');
  check('npm i next@15.0.3 -> allow', bash('npm install next@15.0.3') === 'allow');
} else console.log('SKIP controlli versioni npm (nessuna rete)');

console.log('== guard-edit ==');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gr-'));
fs.mkdirSync(path.join(tmp, 'node_modules', 'tailwindcss'), { recursive: true });
fs.mkdirSync(path.join(tmp, 'node_modules', '@tailwindcss', 'postcss'), { recursive: true });
fs.writeFileSync(path.join(tmp, 'package.json'), '{"name":"t","version":"1.0.0"}');
const ed = (tool, ti) => decision(hook('guard-edit.js', { tool_name: tool, tool_input: ti, cwd: tmp }));
check('postcss config con autoprefixer non installato -> deny',
  ed('Write', { file_path: path.join(tmp, 'postcss.config.mjs'), content: "import tailwindcss from '@tailwindcss/postcss';\nimport autoprefixer from 'autoprefixer';\nexport default {plugins:[tailwindcss(),autoprefixer()]};" }) === 'deny');
check('postcss config valida -> allow',
  ed('Write', { file_path: path.join(tmp, 'postcss.config.mjs'), content: 'const config = { plugins: { "@tailwindcss/postcss": {} } };\nexport default config;' }) === 'allow');
check('postcss config con plugin chiave non installato -> deny',
  ed('Write', { file_path: path.join(tmp, 'postcss.config.mjs'), content: 'export default { plugins: { "autoprefixer": {} } };' }) === 'deny');
const big = path.join(tmp, 'src', 'C.tsx'); fs.mkdirSync(path.dirname(big), { recursive: true });
fs.writeFileSync(big, '"use client";\n' + 'const a = 1;\n'.repeat(80));
check('riscrittura che toglie "use client" -> deny', ed('Write', { file_path: big, content: 'export default function C(){return null}' }) === 'deny');
fs.writeFileSync(big, 'const a = 1;\n'.repeat(80));
check('riscrittura troncata (<50%) -> ask', ed('Write', { file_path: big, content: 'export const x = 1;' }) === 'ask');
check('Write su .env -> ask', ed('Write', { file_path: path.join(tmp, '.env'), content: 'A=1' }) === 'ask');
check('Write su .env.example -> allow', ed('Write', { file_path: path.join(tmp, '.env.example'), content: 'A=' }) === 'allow');
check('modifica package-lock.json -> deny', ed('Edit', { file_path: path.join(tmp, 'package-lock.json'), new_string: 'x', old_string: 'y' }) === 'deny');
check('package.json non valido -> deny', ed('Write', { file_path: path.join(tmp, 'new', 'package.json'), content: '{bad json' }) === 'deny');
if (net) {
  check('package.json con versione inesistente -> deny', ed('Write', { file_path: path.join(tmp, 'x', 'package.json'), content: '{"dependencies":{"drizzle-kit":"^0.24.3"}}' }) === 'deny');
  check('package.json con versioni reali -> allow', ed('Write', { file_path: path.join(tmp, 'y', 'package.json'), content: '{"name":"a","version":"0.1.0","dependencies":{"next":"15.0.3"}}' }) === 'allow');
}

console.log('== post-edit-check ==');
const tsx = path.join(tmp, 'src', 'A.tsx');
fs.writeFileSync(tsx, 'export default function A(){ const [a,setA]=useState(0); return null }');
let r = hook('post-edit-check.js', { tool_input: { file_path: tsx }, cwd: tmp });
check('tsx con useState non importato -> exit 2', r.code === 2, r.code + ' ' + r.err);
fs.writeFileSync(tsx, '"use client";\nimport { useState } from "react";\nexport default function A(){ const [a]=useState(0); return null }');
r = hook('post-edit-check.js', { tool_input: { file_path: tsx }, cwd: tmp });
check('tsx corretto -> exit 0', r.code === 0, r.err);
const js = path.join(tmp, 'bad.json'); fs.writeFileSync(js, '{oops');
r = hook('post-edit-check.js', { tool_input: { file_path: js }, cwd: tmp });
check('json rotto -> exit 2', r.code === 2);

console.log('== verify-stop ==');
const proj = fs.mkdtempSync(path.join(os.tmpdir(), 'gv-'));
fs.writeFileSync(path.join(proj, 'package.json'), '{"name":"p","scripts":{}}');
fs.mkdirSync(path.join(proj, '.claude'));
fs.writeFileSync(path.join(proj, '.claude', 'verify.json'), JSON.stringify({ commands: [{ name: 'falsa', cmd: 'node -e "console.error(\'boom\');process.exit(1)"' }] }));
r = hook('verify-stop.js', { cwd: proj, session_id: 'st1' + Date.now() });
let ok = false; try { const j = JSON.parse(r.out); ok = j.decision === 'block' && /boom/.test(j.reason); } catch (e) {}
check('verifica fallita -> decision block con errore reale', ok, r.out);
fs.writeFileSync(path.join(proj, '.claude', 'verify.json'), JSON.stringify({ commands: [{ name: 'ok', cmd: 'node -e "process.exit(0)"' }] }));
r = hook('verify-stop.js', { cwd: proj, session_id: 'st2' + Date.now() });
check('verifica ok -> systemMessage, nessun blocco', /Verifica automatica OK/.test(r.out) && !/block/.test(r.out), r.out);
// transcript senza modifiche -> nessuna verifica
const tp = path.join(proj, 't.jsonl');
fs.writeFileSync(tp, JSON.stringify({ type: 'user', message: { role: 'user', content: 'ciao' } }) + '\n' + JSON.stringify({ type: 'assistant', message: { content: [{ type: 'text', text: 'ok' }] } }) + '\n');
r = hook('verify-stop.js', { cwd: proj, session_id: 'st3' + Date.now(), transcript_path: tp });
check('turno senza modifiche -> nessun output', r.out === '', r.out);
fs.writeFileSync(tp, JSON.stringify({ type: 'user', message: { role: 'user', content: 'fai' } }) + '\n' + JSON.stringify({ type: 'assistant', message: { content: [{ type: 'tool_use', name: 'Edit', input: {} }] } }) + '\n');
r = hook('verify-stop.js', { cwd: proj, session_id: 'st4' + Date.now(), transcript_path: tp });
check('turno con Edit -> verifica eseguita', /Verifica automatica OK/.test(r.out), r.out);

console.log('== preflight ==');
r = hook('preflight.js', { cwd: proj });
check('preflight stampa inventario', /\[PREFLIGHT\]/.test(r.out) && /REGOLE ATTIVE/.test(r.out), r.out.slice(0, 200));

console.log(fails ? '\n' + fails + ' TEST FALLITI' : '\nTUTTI I TEST OK');
process.exit(fails ? 1 : 0);
