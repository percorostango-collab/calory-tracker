# claude-guardrails — anti-errore per Claude Code (Windows, FreeLLMAPI)

Pensato per gli errori reali visti nella tua sessione Calorie Tracker: versioni npm inventate, `--force`,
config con pacchetti non installati (autoprefixer), file riscritti a metà, server zombie, "funziona!" senza verifica.
La sicurezza dei comandi distruttivi è solo una parte (vedi "Cosa non fa").

## Installazione (2 minuti)
1. Estrai lo zip dove vuoi (es. `D:\ClaudeConfig\claude-guardrails`).
2. Prova senza modificare nulla:
   `node install.js --claude-dir "D:\ClaudeConfig\.claude" --dry-run`
3. Installa (crea il backup `settings.json.bak-<data>`):
   `node install.js --claude-dir "D:\ClaudeConfig\.claude" --claude-md`
   - `--claude-md` aggiunge le regole anti-errore al tuo CLAUDE.md globale (blocco tra marcatori, rieseguibile).
   - `--plugins` (opzionale) disattiva ralph-loop e marketing.
4. **Riavvia Claude Code.** Poi verifica con `node tests/selftest.js` (serve rete per i controlli sulle versioni npm).
Disinstallare: `node install.js --claude-dir "..." --uninstall` (rimuove solo le voci hook di questo pacchetto).

## Cosa cambia in settings.json (nient'altro viene toccato: env, token, autoMode, plugin restano)
- CORRETTO: `autoCompactWindow` era dentro `extraKnownMarketplaces` (posto sbagliato) -> spostato al livello principale.
- `permissions.deny`: lettura di `.env`/`.env.*` e `npm audit fix --force`.
- Hook aggiunti (i tuoi gstack/load-handoff/save-compaction restano):
  | Evento | File | Cosa previene |
  |---|---|---|
  | PreToolUse Bash/PowerShell | guard-bash.js | `--force`/`--legacy-peer-deps`, kill di tutti i node, `npm run dev &`, secondo dev server con porta occupata, versioni npm inesistenti (`npm view`), cat di `.env`, git distruttivi, cancellazione di db/lockfile/.git (chiede conferma) |
  | PreToolUse Write/Edit/MultiEdit | guard-edit.js | package.json con versioni inesistenti, config (postcss/next/tailwind/drizzle...) che importano pacchetti non installati, Write che toglie `"use client"`, riscritture troncate (<50%), sovrascrittura completa di config esistenti, modifica di `.env` e `package-lock.json` |
  | PostToolUse Write/Edit | post-edit-check.js | JSON rotto, hook React non importati / `"use client"` mancante, sintassi Python |
  | SessionStart | preflight.js | inventario: versioni Node/npm, framework, lockfile, node_modules, db, porte occupate, moduli nativi su Windows |
  | Stop | verify-stop.js | se nel turno ci sono state modifiche: `tsc --noEmit`, `npm run build` (solo se nessun dev server attivo), test, GET `/` = 200, CSS = 200, classi Tailwind presenti nel CSS. Se fallisce BLOCCA la chiusura e restituisce all'agente l'errore reale (max 3 volte, poi avvisa te) |
- Skill `safe-project-bootstrap`: procedura per nuovi progetti (scaffolder ufficiale, versioni verificate, verifica, stop dopo 2 fix falliti).

## Verifica specifica per progetto (opzionale)
Crea `.claude/verify.json` nel progetto (esempio: `templates/verify.json.example`):
`commands` (comandi che devono uscire con 0), `urls` (status/testo atteso), `skip` (["tsc","build","tests","http","css","python"]).

## Bypass
Variabile `CLAUDE_GUARD_OFF=1` nell'ambiente da cui avvii Claude Code disattiva tutti gli hook (l'agente non può impostarla).
Le decisioni `ask` ti chiedono conferma; le `deny` si aggirano chiedendo all'agente un'alternativa o disattivando temporaneamente.

## Cosa non fa / limiti noti
- Non sostituisce un sandbox: per i comandi distruttivi in generale aggiungi `CC Safety Net` (`/plugin marketplace add kenryu42/cc-marketplace`, `/plugin install safety-net@cc-marketplace`) o DCG.
- Collaudato in sandbox Linux con Node 22 (test sintetici e server finto). NON ancora provato sulla tua macchina Windows/Claude Code/FreeLLMAPI:
  il nome del tool "PowerShell" nel matcher e il formato del transcript sono assunzioni; se il Stop-hook non parte,
  controlla con `/hooks` in Claude Code che le voci siano elencate.
- L'euristica "classi Tailwind assenti nel CSS" può dare falsi positivi: in tal caso `skip: ["css"]` in verify.json.
- Il Stop-hook non può impedire all'agente di *scrivere* "funziona": gli impedisce di chiudere il turno finché i controlli falliscono.
